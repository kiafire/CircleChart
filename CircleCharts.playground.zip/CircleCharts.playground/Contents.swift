import UIKit

import PlaygroundSupport

var str = "Hello, playground"
struct dataItem {
    var color: UIColor
    var percentage: CGFloat
}

typealias pieAngle = (start: CGFloat, end: CGFloat, color: UIColor)

let piesToDisplay = [dataItem(color: .red, percentage: 10),
            dataItem(color: .blue, percentage: 20),
            dataItem(color: .green, percentage: 25),
            dataItem(color: .yellow, percentage: 25),
            dataItem(color: .orange, percentage: 10)]

class USBCircleChart: UIView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
         
        //let center = self.center
        let angles = calcualteStartAndEndAngle(items: piesToDisplay)

        for i in angles {
            addShapeToCircle(data: i)
        }

    }
    
    func addShapeToCircle(data : pieAngle) {
        var  shapeLayer = CAShapeLayer()
        
        
        // radians = degrees * pi / 180
        // x*2 + y*2 = r*2
        //cos teta = x/r --> x = r * cos teta
        // sinn teta = y/ r -->  y = r * sin teta
        
        let x = 100 * cos(data.start)
        let y = 100 * sin(data.end)
        
        //This is the circle path drawn.
        let circularPath = UIBezierPath(arcCenter: .zero, radius: 100, startAngle: x, endAngle: y, clockwise: true) //2*CGFloat.pi
        
        //
       // let path = CGMutablePath()

       // path.addArc(center: center, radius: 100, startAngle: 0, endAngle: , clockwise: false)
        //
        
        shapeLayer.path = circularPath.cgPath
        
        //Start the angle from anyplace you need { + - of Pi} // {0, 0.5 pi, 1 pi, 1.5pi}
        shapeLayer.transform = CATransform3DMakeRotation(-CGFloat.pi / 2 , 0, 0, 1)
        // color of the stroke
        shapeLayer.strokeColor = data.color.cgColor
        
        //Width of stoke
        shapeLayer.lineWidth = 10
        
        //Starts from the center of the view
        shapeLayer.position = center
        
        
        //To provide a rounded cap on the stroke
        shapeLayer.lineCap = .round
        
        //Fills the entire circle with this color
        shapeLayer.fillColor = UIColor.white.cgColor
        shapeLayer.strokeEnd = 0
        basicAnim(shapeLayer: &shapeLayer)
        layer.addSublayer(shapeLayer)
    }
 
    func basicAnim(shapeLayer: inout CAShapeLayer)  {
        let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        basicAnimation.toValue = 1
        basicAnimation.duration = 10
        
        //Forwards will hold the layer after completion
        basicAnimation.fillMode = .forwards
        basicAnimation.isRemovedOnCompletion = false
        shapeLayer.add(basicAnimation, forKey: "shapeLayerAniamtion")
    }
    
    //Calucate percentage based on given values
    public func calculateAngle(percentageVal:Double)-> CGFloat {
        return CGFloat((percentageVal / 100) * 360)
        let val = CGFloat (percentageVal / 100.0)
        return val * 2 * CGFloat.pi
    }
    
    private func calcualteStartAndEndAngle(items : [dataItem])-> [pieAngle] {
        var angle: pieAngle
        var angleToStart: CGFloat = 0.0
        var angleList: [pieAngle] = []
        for item in items {
            let endAngle = calculateAngle(percentageVal: Double(item.percentage))
            angle.0 = angleToStart
            angle.1 = endAngle
            angle.2 = item.color
            angleList.append(angle)
            angleToStart = endAngle
            print(angle)
        }
        return angleList
    }
    
}


let container = UIView()
container.frame.size = CGSize(width: 360, height: 360)
container.backgroundColor = .white
PlaygroundPage.current.liveView = container
PlaygroundPage.current.needsIndefiniteExecution = true

let m = USBCircleChart(frame: CGRect(x: 0, y: 0, width: 215, height: 215))
m.center = CGPoint(x: container.bounds.size.width / 2, y: container.bounds.size.height / 2)

container.addSubview(m)

